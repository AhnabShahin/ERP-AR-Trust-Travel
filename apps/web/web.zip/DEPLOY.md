# AR Trust Web (Next.js) — server deploy

Source-only package (no `node_modules`, no `.next`). Node 18+ required. The app
is server-rendered, so it must run as a Node app (`next start` / `server.js`),
NOT as a static site.

## Steps

1. Upload `web.zip` to the server and extract it (e.g. `public_html`).

2. Set the API URL. Create `.env.local` from `.env.example`:
   ```
   NEXT_PUBLIC_API_URL=https://your-api-domain.com
   ```
   This is baked in at build time, so it must be set BEFORE `npm run build`.
   It must be the public URL of the API, reachable from the browser.

3. Install and build:
   ```
   npm install
   npm run build
   ```

4. Start:
   ```
   npm start           # next start, port 3000 (override with PORT)
   ```
   On a host that uses a startup file (e.g. Hostinger Node.js App), set the
   startup file to `server.js` (it runs the already-built app).

## Notes
- Rebuild (`npm run build`) whenever `NEXT_PUBLIC_API_URL` changes.
- Images are served from `public/media`; they ship inside this package.
- Don't copy `node_modules`/`.next` from Windows — install and build on the
  server so native binaries match its OS.
