# AR Trust API — server deploy

Source-only package (no `node_modules`, no `dist`). Node 18+ and a MySQL
database required.

## Steps

1. Upload `api.zip` to the server and extract it (e.g. `public_html/api`).

2. Create `.env` from `.env.example` and fill in production values:
   ```
   DATABASE_URL="mysql://USER:PASSWORD@HOST:3306/DATABASE"
   PORT=4000
   CORS_ORIGIN="https://your-web-domain.com"   # the public website origin
   JWT_SECRET="<a long random secret>"
   JWT_EXPIRES_IN="7d"
   NODE_ENV=production
   ```

3. Install dependencies and generate the Prisma client:
   ```
   npm install
   npx prisma generate
   ```

4. Apply database migrations to the production DB:
   ```
   npx prisma migrate deploy
   ```

5. (First setup / intentional reset ONLY) load the production baseline data.
   **This WIPES every table**, so skip it once there is live data:
   ```
   npm run prisma:seed
   ```
   Super-admin after seeding: username `rajib.artrust` (password from the
   client data workbook).

6. Build and start:
   ```
   npm run build
   npm start          # runs node dist/server.js
   ```
   On a host that uses a startup file (e.g. Hostinger Node.js App), set the
   startup file to `dist/server.js`.

## Notes
- The `uploads/` folder stores uploaded images on disk and must stay writable
  and persistent across deploys — don't overwrite it on redeploys.
- `sharp` compiles/installs native binaries for the server's OS during
  `npm install`; install on the server, do not copy `node_modules` from Windows.
- Keep `CORS_ORIGIN` pointed at the real web domain, or the browser will block
  API calls.
